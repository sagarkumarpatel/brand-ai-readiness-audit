"""Finding Composer Engine."""
